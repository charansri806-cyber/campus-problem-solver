import { and, desc, eq, gte, inArray, like, lt, or } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, Issue, issues, issueStatusHistory, issueUpdates, users } from "../drizzle/schema";

let _db: ReturnType<typeof drizzle> | null = null;
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try { _db = drizzle(process.env.DATABASE_URL); }
    catch (error) { console.error("[Database] Connection setup failed:", error); _db = null; }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(users).values(user).onDuplicateKeyUpdate({ set: {
    ...(user.name !== undefined ? { name: user.name } : {}),
    ...(user.email !== undefined ? { email: user.email } : {}),
    ...(user.role !== undefined ? { role: user.role } : {}),
    ...(user.passwordHash !== undefined ? { passwordHash: user.passwordHash } : {}),
    lastSignedIn: new Date(),
  } });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const [row] = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return row;
}

export async function getUserByEmail(email: string) {
  const db = await getDb();
  if (!db) return undefined;
  const [row] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  return row;
}

function escapedLike(value: string) {
  return `%${value.replace(/[\\%_]/g, "\\$&")}%`;
}

export async function listStudentIssues(userId: number, opts: { search?: string; status?: string; category?: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const filters = [eq(issues.reporterId, userId)];
  if (opts.search) {
    const pattern = escapedLike(opts.search.slice(0, 100));
    filters.push(or(like(issues.title, pattern), like(issues.reportId, pattern), like(issues.description, pattern))!);
  }
  if (opts.status) filters.push(eq(issues.status, opts.status as Issue["status"]));
  if (opts.category) filters.push(eq(issues.category, opts.category));
  return db.select().from(issues).where(and(...filters)).orderBy(desc(issues.createdAt)).limit(200);
}

export async function listAdminIssues(opts: { search?: string; status?: string; priority?: string; category?: string; location?: string; dateFrom?: string; dateTo?: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const filters = [];
  if (opts.search) {
    const p = escapedLike(opts.search.slice(0, 100));
    filters.push(or(like(issues.title, p), like(issues.reportId, p), like(issues.description, p), like(issues.location, p))!);
  }
  if (opts.status) filters.push(eq(issues.status, opts.status as Issue["status"]));
  if (opts.priority) filters.push(eq(issues.priority, opts.priority as Issue["priority"]));
  if (opts.category) filters.push(eq(issues.category, opts.category));
  if (opts.location) filters.push(eq(issues.location, opts.location));
  if (opts.dateFrom) filters.push(gte(issues.createdAt, new Date(`${opts.dateFrom}T00:00:00.000Z`)));
  if (opts.dateTo) { const until = new Date(`${opts.dateTo}T00:00:00.000Z`); until.setUTCDate(until.getUTCDate() + 1); filters.push(lt(issues.createdAt, until)); }
  const rows = await db.select({ issue: issues, reporterName: users.name }).from(issues).leftJoin(users, eq(issues.reporterId, users.id)).where(filters.length ? and(...filters) : undefined).orderBy(desc(issues.createdAt)).limit(500);
  return rows.map(row => ({ ...row.issue, reporterName: row.reporterName || "Demo student" }));
}

export async function getIssue(reportId: string, userId: number, admin: boolean) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const filters = [eq(issues.reportId, reportId)];
  if (!admin) filters.push(eq(issues.reporterId, userId));
  const [record] = await db.select({ issue: issues, reporterName: users.name }).from(issues).leftJoin(users, eq(issues.reporterId, users.id)).where(and(...filters)).limit(1);
  if (!record) return null;
  const issue = record.issue;
  const history = await db.select({ id: issueStatusHistory.id, previousStatus: issueStatusHistory.previousStatus, newStatus: issueStatusHistory.newStatus, note: issueStatusHistory.note, createdAt: issueStatusHistory.createdAt, adminName: users.name }).from(issueStatusHistory).leftJoin(users, eq(issueStatusHistory.adminId, users.id)).where(eq(issueStatusHistory.issueId, issue.id)).orderBy(desc(issueStatusHistory.createdAt));
  const updates = await db.select({ id: issueUpdates.id, kind: issueUpdates.kind, note: issueUpdates.note, createdAt: issueUpdates.createdAt, authorName: users.name }).from(issueUpdates).leftJoin(users, eq(issueUpdates.authorId, users.id)).where(eq(issueUpdates.issueId, issue.id)).orderBy(desc(issueUpdates.createdAt));
  return { ...issue, reporterName: record.reporterName || "Demo student", history, updates };
}

function titleSimilarity(a: string, b: string) {
  const tokens = (s: string) => new Set(s.toLowerCase().replace(/[^a-z0-9\s]/g, " ").split(/\s+/).filter(token => token.length > 2));
  const left = tokens(a), right = tokens(b);
  if (!left.size || !right.size) return a.trim().toLowerCase() === b.trim().toLowerCase() ? 1 : 0;
  const overlap = [...left].filter(token => right.has(token)).length;
  return overlap / new Set([...left, ...right]).size;
}

export async function findPotentialDuplicates(input: { title: string; category: string; location: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const recent = new Date(Date.now() - 45 * 24 * 60 * 60 * 1000);
  const rows = await db.select({ reportId: issues.reportId, title: issues.title, category: issues.category, location: issues.location, status: issues.status, createdAt: issues.createdAt }).from(issues)
    .where(and(inArray(issues.status, ["Submitted", "Under Review", "In Progress"]), gte(issues.createdAt, recent), eq(issues.category, input.category), eq(issues.location, input.location)))
    .orderBy(desc(issues.createdAt)).limit(100);
  return rows.filter(row => titleSimilarity(input.title, row.title) >= 0.35).slice(0, 5);
}

export async function createIssue(input: { reporterId: number; title: string; category: string; location: string; description: string; priority: "Low" | "Medium" | "High"; reportId: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.transaction(async tx => {
    const result = await tx.insert(issues).values({ ...input, status: "Submitted" });
    const id = Number(result[0].insertId);
    await tx.insert(issueStatusHistory).values({ issueId: id, previousStatus: null, newStatus: "Submitted", adminId: null, note: "Report submitted by student." });
    const [created] = await tx.select().from(issues).where(eq(issues.id, id)).limit(1);
    return created;
  });
}

export async function updateIssue(input: { reportId: string; adminId: number; status: Issue["status"]; priority: Issue["priority"]; note?: string; noteKind?: "Progress" | "Resolution" }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.transaction(async tx => {
    const [current] = await tx.select().from(issues).where(eq(issues.reportId, input.reportId)).limit(1);
    if (!current) return null;
    const now = new Date();
    await tx.update(issues).set({ status: input.status, priority: input.priority, resolutionNote: input.status === "Resolved" && input.noteKind === "Resolution" && input.note ? input.note : current.resolutionNote, updatedAt: now }).where(eq(issues.id, current.id));
    if (input.status !== current.status || input.priority !== current.priority) {
      const auditNote = input.note || (input.priority !== current.priority ? `Priority changed from ${current.priority} to ${input.priority}.` : null);
      await tx.insert(issueStatusHistory).values({ issueId: current.id, previousStatus: current.status, newStatus: input.status, adminId: input.adminId, note: auditNote });
    }
    if (input.note) await tx.insert(issueUpdates).values({ issueId: current.id, authorId: input.adminId, kind: input.noteKind || "Progress", note: input.note });
    const [updated] = await tx.select().from(issues).where(eq(issues.id, current.id)).limit(1);
    return updated;
  });
}

export async function getAdminAnalytics() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const rows = await db.select().from(issues).orderBy(desc(issues.createdAt));
  const counts = (key: "category" | "location") => Object.entries(rows.reduce<Record<string, number>>((acc, row) => { acc[row[key]] = (acc[row[key]] || 0) + 1; return acc; }, {})).map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count).slice(0, 8);
  const duplicatePairs: { first: Issue; second: Issue; similarity: number }[] = [];
  const cutoff = Date.now() - 45 * 24 * 60 * 60 * 1000;
  const openRecent = rows.filter(row => ["Submitted", "Under Review", "In Progress"].includes(row.status) && new Date(row.createdAt).getTime() >= cutoff);
  for (let i = 0; i < openRecent.length && duplicatePairs.length < 10; i += 1) {
    for (let j = i + 1; j < openRecent.length && duplicatePairs.length < 10; j += 1) {
      const first = openRecent[i]!, second = openRecent[j]!;
      if (first.category !== second.category || first.location !== second.location) continue;
      const similarity = titleSimilarity(first.title, second.title);
      if (similarity >= 0.35) duplicatePairs.push({ first, second, similarity: Number(similarity.toFixed(2)) });
    }
  }
  return {
    total: rows.length,
    open: rows.filter(row => !["Resolved", "Rejected"].includes(row.status)).length,
    review: rows.filter(row => row.status === "Under Review").length,
    inProgress: rows.filter(row => row.status === "In Progress").length,
    resolved: rows.filter(row => row.status === "Resolved").length,
    highPriority: rows.filter(row => row.priority === "High" && !["Resolved", "Rejected"].includes(row.status)).length,
    categories: counts("category"),
    locations: counts("location"),
    duplicatePairs,
    recent: rows.slice(0, 6),
  };
}

export async function getStudentStats(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const rows = await db.select().from(issues).where(eq(issues.reporterId, userId)).orderBy(desc(issues.createdAt));
  return { total: rows.length, awaiting: rows.filter(row => !["Resolved", "Rejected"].includes(row.status)).length, resolved: rows.filter(row => row.status === "Resolved").length, recent: rows.slice(0, 5) };
}
