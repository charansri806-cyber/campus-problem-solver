# Campus Problem Solver — Implementation Plan

## Product and scope

A student-developed innovation prototype for potential presentation to the Institution's Innovation Council at Takshashila University, Chennai. It is not officially approved, operated, or integrated with the University. It is not an emergency service. Do not imply reports are delivered to university personnel. Campus buildings and locations in demo records are explicitly fictional examples. Public production deployment is out of scope until authorization, privacy, and security review.

## Architecture and material choices

Use the initialized React 19 + TypeScript frontend and Express/tRPC + TypeScript server, Drizzle ORM, and the project's managed MySQL database. The source prompt calls SQLite the preferred database for a local prototype; managed MySQL was approved instead because this is a hosted, persistent WebDev project. Development and any published deployment share this database, so seeds must be idempotent, demo data visibly marked, and reset instructions non-destructive by default. Use the generated runtime config and avoid resetting or deleting shared data.

Create user, issue, status-history, and administrator-update records with foreign keys and useful indexes. Seed fictional student/admin demo accounts with scrypt-hashed passwords (never plaintext) and distinct demo reports. Implement a purpose-built demo login with a signed, HTTP-only, SameSite cookie using a dedicated app cookie name; verify identity/role/expiry server-side on all private routes. Do not expose demo admin credentials in browser code. Student queries always scope by the authenticated user; administrator procedures require the admin role. Validate request content and lengths server-side. Avoid insecure uploads, email integrations, and claims of real staff notification.

The web UI will have a clear prototype/emergency notice, student and administrator dashboards, submission form, searchable/filterable report list, issue detail/history, and admin management/analytics. Duplicate checking is transparent, deterministic title/category/location similarity over recent open reports; it warns with report IDs and never merges/deletes. Analytics are computed from database queries. Responsive navigation and accessible focus, contrast, labels, statuses, and form errors are included. The user has now supplied the Takshashila University logo; display its original image unchanged in the login and workspace brand areas, with a separate independent student-prototype identity. Do not imply University endorsement or invent official brand rules, locations, contacts, departments, or staff.

## Project structure

- `client/src/App.tsx` — route table, login, shared shell, student dashboards/list/detail/form, administrator dashboards/management, reusable badges and empty/error states.
- `client/src/main.tsx`, `client/src/lib/trpc.ts` — React bootstrap and typed API client.
- `client/src/index.css` — responsive visual system, page layouts, status styling, focus states and reduced-motion override.
- `server/_core/` — Express startup, request context and middleware; `server/routers.ts` — role-checked tRPC procedures.
- `server/db.ts` — database queries, ownership-scoped detail, analytics, duplicate heuristics and transactional issue/history updates.
- `server/auth/demo.ts` — demo password verification, signed-session and cookie helpers; `server/auth/demo.test.ts` — auth-helper unit tests.
- `drizzle/schema.ts`, `drizzle/` — relational schema, migration SQL, migration metadata and snapshots.
- `scripts/seed-demo.ts`, `scripts/verify-demo.ts` — idempotent fictional seed and read-only backend verifier.
- `client/public/manus-routes.json` — page-route declaration synchronized with the actual route table.
- `branding/`, `app.config.ts` — neutral product mark for project metadata, explicitly not the University logo.
- `README.md`, `.env.example`, `TODO.md` — setup, demo credentials, migration/seed instructions, tests, architecture, limitations, deployment/security notes and acceptance progress.

## Design

The supplied logo is the visual reference: build on clean white and soft-neutral surfaces, graphite/charcoal structure and typography, and an orange accent sampled from the original mark (#F05D2D). Use the orange for restrained primary actions, focus details and selected states; choose a darker accessible orange for text on white, and keep alert/status colors semantically distinct. Use a calm editorial hierarchy rather than a generic template: a persistent graphite navigation rail on desktop, compact top/mobile navigation, and content pages with a strong title/description header and compact KPI strip. Signature details are the unchanged logo on a light backing, an orange prototype label, clear status pills with icons/text (not color alone), and a vertical timeline for report history. Interactions should be direct and predictable with visible keyboard focus, loading/success/empty/error states, reduced motion, and no decorative controls without behavior. Use a legible sans-serif interface font stack with distinct weight/size hierarchy. These are interface choices inspired by the supplied image, not assertions about official University brand rules or endorsement.

**Brand essence:** A practical campus feedback tracker for students, designed to make issue progress clear; approachable, accountable, restrained.

**Brand voice:** Clear and factual, never implying official operations. Example lines: “Track a campus issue from submission to resolution.” “Prototype only — urgent concerns should be reported directly to the appropriate personnel or emergency services.”

**Signature color:** logo-inspired orange #F05D2D, paired with graphite #3D444A and warm white; these are interface choices sampled from the user-supplied image, not official brand guidelines.

## Runtime and delivery

Use the provided WebDev runtime and managed MySQL; preserve secrets in environment configuration only. Create deterministic Drizzle migrations, setup and idempotent demo-seed instructions, and tests for core authorization/data paths. Run TypeScript checks, tests, build, start and readiness checks, and verify `/manus-routes.json`. Do not publish publicly. Report what is implemented and tested versus incomplete, note that the supplied logo is included unchanged, and call out the required University authorization.
