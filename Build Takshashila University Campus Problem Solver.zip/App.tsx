import { FormEvent, useEffect, useMemo, useState } from "react";
import { Link, Route, Switch, useLocation, useRoute } from "wouter";
import { Activity, AlertTriangle, ArrowDownRight, ArrowRight, ArrowUpRight, BarChart3, Check, CheckCircle2, ChevronRight, Clock3, FilePlus2, Filter, LayoutDashboard, LogOut, MapPin, Search, ShieldCheck, SlidersHorizontal, Wrench } from "lucide-react";
import { trpc } from "@/lib/trpc";

const categories = ["Classroom & laboratory equipment", "Cleanliness & waste", "Water & washroom maintenance", "Wi-Fi & campus technology", "Building & infrastructure", "Library & study spaces", "Accessibility & non-emergency safety", "Other campus facilities"] as const;
const locations = ["Sample location — North learning wing", "Sample location — Central library", "Sample location — Student commons", "Sample location — West laboratory block", "Sample location — Outdoor walkways"];
const statuses = ["Submitted", "Under Review", "In Progress", "Resolved", "Rejected"] as const;
const priorities = ["Low", "Medium", "High"] as const;
type Role = "student" | "admin" | "user";
type SessionUser = { id: number; name: string | null; email: string | null; role: Role };
type Issue = { id: number; reportId: string; title: string; category: string; location: string; description: string; priority: "Low" | "Medium" | "High"; status: typeof statuses[number]; createdAt: Date | string; updatedAt: Date | string; reporterName?: string | null };

function formatDate(value: Date | string) {
  return new Intl.DateTimeFormat("en-IN", { day: "numeric", month: "short", year: "numeric" }).format(new Date(value));
}
function StatusPill({ status }: { status: string }) {
  const icon = status === "Resolved" ? <Check size={13} /> : status === "In Progress" ? <Wrench size={13} /> : status === "Rejected" ? <AlertTriangle size={13} /> : <Clock3 size={13} />;
  return <span className={`status status-${status.toLowerCase().replaceAll(" ", "-")}`}>{icon}{status}</span>;
}
function PriorityPill({ priority }: { priority: string }) {
  return <span className={`priority priority-${priority.toLowerCase()}`}><span />{priority}</span>;
}
function LogoMark({ compact = false }: { compact?: boolean }) {
  return <div className={`brand brand-university ${compact ? "brand-compact" : ""}`}><div className="university-logo-frame"><img className="university-logo" src="/manus-storage/takshashila-university-logo_7bd24622.png" alt="Takshashila University" width="300" height="90" /></div><div className="brand-product"><div className="brand-symbol" aria-hidden="true"><Activity size={19} /></div><div><strong>Campus<span>Solve</span></strong><small>STUDENT PROTOTYPE</small></div></div></div>;
}
function PrototypeNotice({ compact = false }: { compact?: boolean }) {
  return <div className={`prototype-notice ${compact ? "compact" : ""}`}><ShieldCheck size={15} /><span>Independent student-developed prototype — not an official University service.</span></div>;
}
function PageHeader({ eyebrow, title, description, action }: { eyebrow?: string; title: string; description?: string; action?: React.ReactNode }) {
  return <div className="page-header"><div>{eyebrow && <div className="eyebrow">{eyebrow}</div>}<h1>{title}</h1>{description && <p>{description}</p>}</div>{action}</div>;
}
function StatCard({ label, value, icon: Icon, tone = "blue", footnote }: { label: string; value: number; icon: React.ElementType; tone?: string; footnote?: string }) {
  return <article className="stat-card"><div className={`stat-icon ${tone}`}><Icon size={18} /></div><div><p>{label}</p><strong>{value}</strong>{footnote && <small>{footnote}</small>}</div><ArrowDownRight className="stat-arrow" size={17} /></article>;
}
function IssueRow({ issue, admin = false }: { issue: Issue; admin?: boolean }) {
  return <Link href={`/reports/${issue.reportId}`} className="issue-row"><div className="issue-main"><div className="issue-title-line"><strong>{issue.title}</strong><span className="report-id">{issue.reportId}</span></div><div className="issue-meta"><span><MapPin size={13} />{issue.location.replace("Sample location — ", "")}</span><span>{issue.category}</span>{admin && issue.reporterName && <span>Reported by {issue.reporterName}</span>}</div></div><div className="issue-end"><StatusPill status={issue.status} /><div className="issue-date">{formatDate(issue.createdAt)}</div></div><ChevronRight size={17} className="row-chevron" /></Link>;
}
function EmptyState({ title, body, action }: { title: string; body: string; action?: React.ReactNode }) {
  return <div className="empty-state"><div className="empty-icon"><FilePlus2 size={23} /></div><h3>{title}</h3><p>{body}</p>{action}</div>;
}

function LoginPage() {
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();
  const login = trpc.auth.login.useMutation({ onSuccess: async user => { await utils.auth.me.invalidate(); setLocation(user.role === "admin" ? "/admin" : "/student"); } });
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  function submit(event: FormEvent) { event.preventDefault(); login.mutate({ email, password }); }
  return <main className="login-page"><aside className="login-story"><div className="story-top"><LogoMark /></div><div className="story-content"><div className="story-kicker"><span />A BETTER WAY TO RAISE CAMPUS ISSUES</div><h1>Small fixes make<br />a better <em>campus.</em></h1><p>A clear place to document a campus concern and follow its progress — from your first report to the latest update.</p><div className="story-steps"><div><b>01</b><span><strong>Tell us what needs attention</strong><small>Share a location and a few details.</small></span></div><div><b>02</b><span><strong>Keep your report close</strong><small>Find your reference ID and progress here.</small></span></div></div></div><div className="story-footer">A student innovation prototype for potential IIC presentation</div></aside><section className="login-panel"><div className="mobile-brand"><LogoMark /></div><div className="login-form-wrap"><div className="login-heading"><span className="eyebrow">CAMPUS PROBLEM SOLVER</span><h2>Sign in to continue</h2><p>Use a fictional demo account from the project README.</p></div><form className="form-stack" onSubmit={submit}><label>Email address<input type="email" autoComplete="username" required maxLength={320} value={email} onChange={event => setEmail(event.target.value)} placeholder="you@example.edu" /></label><label>Password<input type="password" autoComplete="current-password" required maxLength={128} value={password} onChange={event => setPassword(event.target.value)} placeholder="Enter your password" /></label>{login.error && <div className="inline-error" role="alert">{login.error.message}</div>}<button className="button primary full" type="submit" disabled={login.isPending}>{login.isPending ? "Signing in…" : "Sign in"}<ArrowRight size={16} /></button></form><PrototypeNotice /><p className="login-footnote">This prototype is not operated by Takshashila University. Do not enter real student or sensitive personal information.</p></div><footer className="login-panel-footer">© Campus Problem Solver · Student project</footer></section></main>;
}

function AppShell({ user, children }: { user: SessionUser; children: React.ReactNode }) {
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();
  const logout = trpc.auth.logout.useMutation({ onSuccess: async () => { await utils.auth.me.invalidate(); setLocation("/login"); } });
  const admin = user.role === "admin";
  const links = admin ? [{ href: "/admin", label: "Overview", icon: LayoutDashboard }, { href: "/admin/reports", label: "All reports", icon: FilePlus2 }] : [{ href: "/student", label: "Overview", icon: LayoutDashboard }, { href: "/reports", label: "My reports", icon: FilePlus2 }];
  return <div className="app-shell"><aside className="sidebar"><Link href={admin ? "/admin" : "/student"} className="sidebar-brand"><LogoMark /></Link><div className="sidebar-section-label">WORKSPACE</div><nav className="side-nav">{links.map(({ href, label, icon: Icon }) => <Link key={href} href={href} className="side-link"><Icon size={17} />{label}<ChevronRight size={14} className="side-chevron" /></Link>)}</nav><div className="sidebar-bottom"><PrototypeNotice compact /><div className="user-card"><div className="avatar">{(user.name || "U").charAt(0).toUpperCase()}</div><div className="user-info"><strong>{user.name || "Demo account"}</strong><small>{admin ? "Administrator demo" : "Student demo"}</small></div><button aria-label="Sign out" className="icon-button logout-button" onClick={() => logout.mutate()} disabled={logout.isPending}><LogOut size={16} /></button></div></div></aside><div className="main-column"><header className="topbar"><div className="mobile-top-brand"><LogoMark compact /></div><div className="topbar-label">{admin ? "ADMINISTRATION" : "STUDENT PORTAL"}<span className="prototype-chip">DEMO</span></div><div className="topbar-user"><span className="live-dot" />Private demo workspace</div></header><main className="content-area">{children}<footer className="site-footer"><span>Campus Problem Solver <b>·</b> Student innovation prototype</span><span>Not an official University service</span></footer></main></div><div className="mobile-nav">{links.map(({ href, label, icon: Icon }) => <Link key={href} href={href}><Icon size={18} />{label}</Link>)}<button onClick={() => logout.mutate()}><LogOut size={18} />Sign out</button></div></div>;
}

function StudentDashboard({ user }: { user: SessionUser }) {
  const stats = trpc.student.stats.useQuery();
  const [lookup, setLookup] = useState("");
  const [, setLocation] = useLocation();
  function openLookup(event: FormEvent) { event.preventDefault(); const query = lookup.trim(); if (query) setLocation(`/reports?search=${encodeURIComponent(query)}`); }
  if (stats.isLoading) return <Loading />;
  if (stats.error) return <ErrorPanel message="We couldn't load your dashboard." retry={() => stats.refetch()} />;
  const data = stats.data!;
  return <><PageHeader eyebrow="YOUR CAMPUS, IN FOCUS" title={`Good day, ${(user.name || "student").split(" ")[0]}.`} description="A little clarity goes a long way. See where your reports stand." action={<Link className="button primary" href="/reports/new"><FilePlus2 size={17} />Report a problem</Link>} /><div className="stats-grid"><StatCard label="All your reports" value={data.total} icon={FilePlus2} /><StatCard label="Awaiting resolution" value={data.awaiting} icon={Clock3} tone="amber" /><StatCard label="Resolved" value={data.resolved} icon={CheckCircle2} tone="green" /></div><div className="content-split"><section className="panel"><div className="panel-heading"><div><h2>Recent reports</h2><p>Updates to issues you've raised.</p></div><Link href="/reports" className="text-link">View all <ArrowRight size={15} /></Link></div>{data.recent.length ? <div className="issue-list">{data.recent.map(issue => <IssueRow key={issue.id} issue={issue} />)}</div> : <EmptyState title="Nothing reported yet" body="When you submit a campus issue, it will appear here." action={<Link className="button secondary small" href="/reports/new">Create your first report</Link>} />}</section><aside className="side-stack"><section className="panel quick-lookup"><div className="panel-heading"><div><h2>Find a report</h2><p>Look up your report ID or title</p></div><Search size={17} className="muted-icon" /></div><form onSubmit={openLookup}><label className="sr-only" htmlFor="dashboard-report-search">Search your reports</label><input id="dashboard-report-search" value={lookup} onChange={e => setLookup(e.target.value)} placeholder="e.g. CPS-2026-AB12CD34" /><button className="button secondary full" disabled={!lookup.trim()}><Search size={15} />Find in my reports</button></form></section><div className="tip-card"><div className="tip-icon"><Activity size={18} /></div><span className="eyebrow">HOW IT WORKS</span><h3>Your report, with a clear trail.</h3><p>Use your report ID to find the latest status and any administrator notes.</p><div className="tip-rule" /><div className="mini-step"><span>1</span>Submit a campus concern</div><div className="mini-step"><span>2</span>Keep the report reference</div><div className="mini-step"><span>3</span>Check back for updates</div></div><div className="urgent-card"><AlertTriangle size={17} /><div><strong>Need urgent help?</strong><p>This prototype is not an emergency service. Contact appropriate University personnel or emergency services directly.</p></div></div></aside></div></>;
}

function NewReportPage() {
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();
  const [form, setForm] = useState({ title: "", category: categories[0] as typeof categories[number], location: locations[0], description: "", priority: "Medium" as "Low" | "Medium" | "High" });
  const [duplicates, setDuplicates] = useState<{ reportId: string; title: string; status: string; createdAt: Date | string }[]>([]);
  const [duplicateConfirmed, setDuplicateConfirmed] = useState(false);
  const submit = trpc.student.submit.useMutation({ onSuccess: async result => {
    if (!result.created) { setDuplicates(result.potentialDuplicates); setDuplicateConfirmed(false); return; }
    await Promise.all([utils.student.stats.invalidate(), utils.student.list.invalidate()]);
    setLocation(`/reports/${result.created.reportId}?created=1`);
  } });
  function set<K extends keyof typeof form>(key: K, value: typeof form[K]) { setForm(current => ({ ...current, [key]: value })); setDuplicateConfirmed(false); setDuplicates([]); }
  function handle(event: FormEvent) { event.preventDefault(); submit.mutate({ ...form, confirmPotentialDuplicate: duplicateConfirmed }); }
  return <><PageHeader eyebrow="NEW REPORT" title="Report a problem" description="Share a campus issue so you can keep its details and updates together." /><PrototypeNotice /><form className="report-form layout-narrow" onSubmit={handle}><div className="form-card"><div className="form-card-heading"><span className="step-index">01</span><div><h2>What needs attention?</h2><p>Describe the issue as clearly as you can.</p></div></div><label>Issue title <em>Required</em><input required minLength={5} maxLength={140} value={form.title} onChange={e => set("title", e.target.value)} placeholder="For example, projector not powering on" /></label><div className="form-grid"><label>Category <em>Required</em><select value={form.category} onChange={e => set("category", e.target.value as typeof categories[number])}>{categories.map(item => <option key={item}>{item}</option>)}</select></label><label>Campus location <em>Required</em><select value={form.location} onChange={e => set("location", e.target.value)}>{locations.map(item => <option key={item}>{item}</option>)}</select></label></div><label>Detailed description <em>Required</em><textarea required minLength={15} maxLength={5000} rows={5} value={form.description} onChange={e => set("description", e.target.value)} placeholder="What happened? Add details that could help someone understand the issue." /><small className="field-help">Please avoid names, contact details, or sensitive personal information. {form.description.length}/5000</small></label><label>Priority</label><div className="priority-select">{priorities.map(priority => <label key={priority} className={form.priority === priority ? "selected" : ""}><input type="radio" name="priority" value={priority} checked={form.priority === priority} onChange={() => set("priority", priority)} /><span className={`priority-dot ${priority.toLowerCase()}`} /><span><strong>{priority}</strong><small>{priority === "High" ? "Needs timely attention" : priority === "Low" ? "Can be addressed when convenient" : "Standard attention"}</small></span></label>)}</div>{submit.error && <div className="inline-error" role="alert">{submit.error.message}</div>}{duplicates.length > 0 && !duplicateConfirmed && <div className="duplicate-warning"><div className="duplicate-heading"><AlertTriangle size={18} /><div><strong>Similar open reports found</strong><p>Compare these before deciding whether to submit another report. Matching is based on recent category, location, and title similarity—not AI.</p></div></div><div className="duplicate-list">{duplicates.map(item => <Link key={item.reportId} href={`/reports/${item.reportId}`}><span><b>{item.reportId}</b> · {item.title}</span><StatusPill status={item.status} /></Link>)}</div><button type="button" className="button secondary small" onClick={() => setDuplicateConfirmed(true)}>Continue with a separate report</button></div>}<div className="form-actions"><Link href="/student" className="button quiet">Cancel</Link><button type="submit" className="button primary" disabled={submit.isPending}>{submit.isPending ? "Saving report…" : duplicateConfirmed ? "Submit separate report" : "Submit report"}<ArrowRight size={16} /></button></div></div><div className="form-footnote"><ShieldCheck size={15} />Your report is saved in this prototype. It is not sent to University staff.</div></form></>;
}

function StudentReportsPage() {
  const [currentLocation] = useLocation();
  const initialSearch = new URLSearchParams(currentLocation.split("?")[1] || "").get("search") || "";
  const [search, setSearch] = useState(initialSearch);
  const [status, setStatus] = useState("");
  const results = trpc.student.list.useQuery({ search: search || undefined, status: status ? status as typeof statuses[number] : undefined });
  return <><PageHeader eyebrow="YOUR ACTIVITY" title="My reports" description="Search your submissions and follow the latest status." action={<Link className="button primary" href="/reports/new"><FilePlus2 size={17} />New report</Link>} /><div className="filters-bar"><label className="search-box"><Search size={17} /><input placeholder="Search by title or report ID" value={search} onChange={e => setSearch(e.target.value)} /></label><label className="filter-control"><Filter size={15} /><select value={status} onChange={e => setStatus(e.target.value)}><option value="">All statuses</option>{statuses.map(item => <option key={item}>{item}</option>)}</select></label></div>{results.isLoading ? <Loading /> : results.error ? <ErrorPanel message="Your reports could not be loaded." retry={() => results.refetch()} /> : results.data?.length ? <section className="panel"><div className="issue-list">{results.data.map(issue => <IssueRow key={issue.id} issue={issue} />)}</div></section> : <EmptyState title={search || status ? "No reports match" : "No reports yet"} body={search || status ? "Try a different search or status filter." : "Your submitted reports will appear here."} />}</>;
}

function ReportDetailPage({ admin }: { admin: boolean }) {
  const [, params] = useRoute("/reports/:id");
  const reportId = params?.id || "";
  const [currentLocation] = useLocation();
  const justCreated = currentLocation.includes("created=1");
  const studentQuery = trpc.student.detail.useQuery({ reportId }, { enabled: !admin, retry: false });
  const adminQuery = trpc.admin.detail.useQuery({ reportId }, { enabled: admin, retry: false });
  const detail = admin ? adminQuery.data : studentQuery.data;
  const error = admin ? adminQuery.error : studentQuery.error;
  const loading = admin ? adminQuery.isLoading : studentQuery.isLoading;
  const utils = trpc.useUtils();
  const update = trpc.admin.update.useMutation({ onSuccess: async () => { await Promise.all([utils.admin.detail.invalidate(), utils.admin.list.invalidate(), utils.admin.analytics.invalidate()]); } });
  const [nextStatus, setNextStatus] = useState<typeof statuses[number] | "">("");
  const [nextPriority, setNextPriority] = useState<typeof priorities[number] | "">("");
  const [note, setNote] = useState("");
  const [noteKind, setNoteKind] = useState<"Progress" | "Resolution">("Progress");
  if (loading) return <Loading />;
  if (error || !detail) return <ErrorPanel message="This report could not be found or is not available to this account." retry={() => admin ? adminQuery.refetch() : studentQuery.refetch()} />;
  const status = nextStatus || detail.status;
  const priority = nextPriority || detail.priority;
  return <><div className="breadcrumbs"><Link href={admin ? "/admin/reports" : "/reports"}>{admin ? "All reports" : "My reports"}</Link><ChevronRight size={14} />{detail.reportId}</div><PageHeader eyebrow={detail.reportId} title={detail.title} description={`${detail.category} · ${detail.location}`} />{justCreated && <div className="creation-success"><CheckCircle2 size={18} /><div><strong>Report saved successfully</strong><p>Your unique report ID is <b>{detail.reportId}</b>. This issue is stored in the prototype and has not been sent to University staff.</p></div></div>}<div className="detail-layout"><div className="detail-main"><section className="panel detail-summary"><div className="detail-badges"><StatusPill status={detail.status} /><PriorityPill priority={detail.priority} /><span className="report-date">Submitted {formatDate(detail.createdAt)}</span></div><h2>What was reported</h2><p className="description-text">{detail.description}</p>{admin && <div className="reporter-line"><span className="avatar mini">{(detail.reporterName || "S").charAt(0)}</span>Submitted by <strong>{detail.reporterName || "Demo student"}</strong></div>}{!admin && detail.resolutionNote && <div className="resolution-note"><CheckCircle2 size={18} /><div><strong>Resolution note</strong><p>{detail.resolutionNote}</p></div></div>}</section><section className="panel timeline-panel"><div className="panel-heading"><div><h2>Update history</h2><p>Report status changes and administrator notes.</p></div></div>{detail.history.length ? <div className="timeline">{detail.history.map((entry: any) => <div className="timeline-item" key={entry.id}><span className="timeline-dot" /><div className="timeline-content"><div className="timeline-top"><strong>{entry.newStatus}</strong><time>{formatDate(entry.createdAt)}</time></div>{entry.previousStatus && <p>Status changed from {entry.previousStatus}</p>}{entry.note && <p className="timeline-note">{entry.note}</p>}{entry.adminName && <small>Updated by {entry.adminName}</small>}</div></div>)}</div> : <p className="muted-note">No status updates have been recorded.</p>}{detail.updates.length > 0 && <div className="admin-notes"><h3>Progress notes</h3>{detail.updates.map((item: any) => <div className="admin-note" key={item.id}><span>{item.kind} · {formatDate(item.createdAt)}</span><p>{item.note}</p><small>{item.authorName || "Administrator"}</small></div>)}</div>}</section></div>{admin && <aside className="admin-edit panel"><div className="admin-edit-head"><div className="stat-icon blue"><SlidersHorizontal size={17} /></div><h2>Manage report</h2><p>Updates are recorded in the report history.</p></div><form className="form-stack" onSubmit={e => { e.preventDefault(); update.mutate({ reportId: detail.reportId, status: status as typeof statuses[number], priority: priority as typeof priorities[number], note: note || undefined, noteKind: note ? noteKind : undefined }); setNote(""); }}><label>Status<select value={status} onChange={e => setNextStatus(e.target.value as typeof statuses[number])}>{statuses.map(item => <option key={item}>{item}</option>)}</select></label><label>Priority<select value={priority} onChange={e => setNextPriority(e.target.value as typeof priorities[number])}>{priorities.map(item => <option key={item}>{item}</option>)}</select></label><label>Update note<textarea rows={4} maxLength={2000} value={note} onChange={e => setNote(e.target.value)} placeholder="Add a progress or resolution note (optional)" /></label><label>Note type<select value={noteKind} onChange={e => setNoteKind(e.target.value as "Progress" | "Resolution")}><option>Progress</option><option>Resolution</option></select></label>{update.error && <div className="inline-error">{update.error.message}</div>}{update.isSuccess && <div className="inline-success"><CheckCircle2 size={15} />Update saved.</div>}<button className="button primary full" disabled={update.isPending}>{update.isPending ? "Saving…" : "Save update"}<ArrowRight size={15} /></button></form><p className="admin-edit-foot">Only this prototype's administrator demo can make report changes.</p></aside>}</div></>;
}

function AdminDashboard() {
  const data = trpc.admin.analytics.useQuery();
  if (data.isLoading) return <Loading />;
  if (data.error) return <ErrorPanel message="Admin analytics could not be loaded." retry={() => data.refetch()} />;
  const a = data.data!;
  return <><PageHeader eyebrow="CAMPUS OPERATIONS · DEMO" title="Issue overview" description="A database-backed view of submitted demo reports." action={<Link className="button primary" href="/admin/reports"><FilePlus2 size={16} />Manage reports</Link>} /><div className="stats-grid admin-stats"><StatCard label="Total reports" value={a.total} icon={FilePlus2} /><StatCard label="Open reports" value={a.open} icon={Clock3} tone="amber" /><StatCard label="Under review" value={a.review} icon={Search} tone="amber" /><StatCard label="In progress" value={a.inProgress} icon={Wrench} tone="blue" /><StatCard label="Resolved" value={a.resolved} icon={CheckCircle2} tone="green" /><StatCard label="High priority · open" value={a.highPriority} icon={AlertTriangle} tone="red" /></div><div className="content-split admin-split"><section className="panel"><div className="panel-heading"><div><h2>Recent activity</h2><p>Latest reports from the prototype database.</p></div><Link href="/admin/reports" className="text-link">All reports <ArrowRight size={15} /></Link></div>{a.recent.length ? <div className="issue-list">{a.recent.map(issue => <IssueRow key={issue.id} issue={issue} admin />)}</div> : <EmptyState title="No reports in this workspace" body="Newly submitted reports will show up here." />}</section><aside className="side-stack"><section className="panel analytics-card duplicate-admin-card"><div className="panel-heading"><div><h2>Potential duplicates</h2><p>Same category/location + similar title · heuristic only</p></div><AlertTriangle size={17} className="muted-icon" /></div>{a.duplicatePairs.length ? a.duplicatePairs.map(pair => <Link className="duplicate-pair" key={`${pair.first.reportId}-${pair.second.reportId}`} href={`/reports/${pair.first.reportId}`}><strong>{pair.first.title} <span>↔</span> {pair.second.title}</strong><small>{pair.first.reportId} · {pair.second.reportId}</small></Link>) : <p className="muted-note">No recent open pairs met the matching rule.</p>}</section><section className="panel analytics-card"><div className="panel-heading"><div><h2>By category</h2><p>Counts from stored reports</p></div><BarChart3 size={18} className="muted-icon" /></div>{a.categories.length ? a.categories.map(item => <div className="bar-row" key={item.name}><div><span>{item.name}</span><b>{item.count}</b></div><div className="bar-track"><span style={{ width: `${Math.max(8, item.count / Math.max(...a.categories.map(x => x.count)) * 100)}%` }} /></div></div>) : <p className="muted-note">No category data yet.</p>}</section><section className="panel analytics-card"><div className="panel-heading"><div><h2>By sample location</h2><p>Fictional demo locations</p></div><MapPin size={17} className="muted-icon" /></div>{a.locations.length ? a.locations.slice(0, 5).map(item => <div className="location-row" key={item.name}><span>{item.name.replace("Sample location — ", "")}</span><b>{item.count}</b></div>) : <p className="muted-note">No location data yet.</p>}</section><div className="admin-disclaimer"><ShieldCheck size={16} /><p>Prototype analytics only. These figures describe demo records, not University operations or performance.</p></div></aside></div></>;
}

function AdminReportsPage() {
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");
  const [priority, setPriority] = useState("");
  const [category, setCategory] = useState("");
  const [location, setLocation] = useState("");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const input = useMemo(() => ({ search: search || undefined, status: status ? status as typeof statuses[number] : undefined, priority: priority ? priority as typeof priorities[number] : undefined, category: category || undefined, location: location || undefined, dateFrom: dateFrom || undefined, dateTo: dateTo || undefined }), [search, status, priority, category, location, dateFrom, dateTo]);
  const result = trpc.admin.list.useQuery(input);
  return <><PageHeader eyebrow="REPORT MANAGEMENT" title="All reports" description="Search and review every issue in this prototype workspace." /><section className="panel filters-panel"><div className="filters-bar admin-filters"><label className="search-box"><Search size={17} /><input placeholder="Search title, report ID, description…" value={search} onChange={e => setSearch(e.target.value)} /></label><label className="filter-control"><Filter size={15} /><select value={status} onChange={e => setStatus(e.target.value)}><option value="">All statuses</option>{statuses.map(item => <option key={item}>{item}</option>)}</select></label><label className="filter-control"><select aria-label="Filter by priority" value={priority} onChange={e => setPriority(e.target.value)}><option value="">All priorities</option>{priorities.map(item => <option key={item}>{item}</option>)}</select></label><label className="filter-control wide"><select aria-label="Filter by category" value={category} onChange={e => setCategory(e.target.value)}><option value="">All categories</option>{categories.map(item => <option key={item}>{item}</option>)}</select></label><label className="filter-control wide"><select aria-label="Filter by location" value={location} onChange={e => setLocation(e.target.value)}><option value="">All sample locations</option>{locations.map(item => <option key={item}>{item}</option>)}</select></label><label className="filter-control date-filter"><span>From</span><input aria-label="Filter from date" type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} /></label><label className="filter-control date-filter"><span>To</span><input aria-label="Filter to date" type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} /></label></div></section>{result.isLoading ? <Loading /> : result.error ? <ErrorPanel message="Reports could not be loaded." retry={() => result.refetch()} /> : result.data?.length ? <section className="panel"><div className="list-summary">{result.data.length} report{result.data.length === 1 ? "" : "s"} · filtered results</div><div className="issue-list">{result.data.map(issue => <IssueRow key={issue.id} issue={issue} admin />)}</div></section> : <EmptyState title="No matching reports" body="Try a broader search or remove a filter." />}</>;
}

function Loading() { return <div className="loading-state"><span className="spinner" />Loading workspace…</div>; }
function ErrorPanel({ message, retry }: { message: string; retry: () => void }) { return <div className="error-panel"><AlertTriangle size={19} /><div><strong>Something didn't load</strong><p>{message}</p><button className="text-link" onClick={retry}>Try again <ArrowRight size={14} /></button></div></div>; }
function NotFoundPage() { return <div className="not-found"><div className="empty-icon"><Search size={22} /></div><h1>That page isn't here</h1><p>It may have moved, or this account may not have access.</p><Link href="/student" className="button primary">Go to dashboard</Link></div>; }

export default function App() {
  const [path, setLocation] = useLocation();
  const session = trpc.auth.me.useQuery(undefined, { retry: false });
  useEffect(() => { if (session.data && (path === "/" || path === "/login")) setLocation(session.data.role === "admin" ? "/admin" : "/student"); }, [session.data, path, setLocation]);
  if (session.isLoading) return <Loading />;
  if (session.error) return <div className="full-error">Unable to check your demo session. Refresh to try again.</div>;
  const user = session.data as SessionUser | null;
  if (!user) return <Switch><Route path="/login" component={LoginPage} /><Route component={LoginPage} /></Switch>;
  const admin = user.role === "admin";
  return <AppShell user={user}><Switch>
    {admin ? <>
      <Route path="/admin" component={AdminDashboard} />
      <Route path="/admin/reports" component={AdminReportsPage} />
      <Route path="/reports/:id"><ReportDetailPage admin /></Route>
      <Route path="/student"><NotFoundPage /></Route>
    </> : <>
      <Route path="/student"><StudentDashboard user={user} /></Route>
      <Route path="/reports"><StudentReportsPage /></Route>
      <Route path="/reports/new"><NewReportPage /></Route>
      <Route path="/reports/:id"><ReportDetailPage admin={false} /></Route>
      <Route path="/admin"><NotFoundPage /></Route>
      <Route path="/admin/reports"><NotFoundPage /></Route>
    </>}
    <Route path="/login"><StudentDashboard user={user} /></Route>
    <Route component={NotFoundPage} />
  </Switch></AppShell>;
}
