import { createHash, randomBytes, scrypt as scryptCb, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import type { CookieOptions, Request, Response } from "express";
import { SignJWT, jwtVerify } from "jose";
import { getUserByOpenId } from "../db";

const scrypt = promisify(scryptCb);
export const DEMO_COOKIE = "campus_problem_session";
const SESSION_SECONDS = 60 * 60 * 12;

function sessionKey() {
  const source = process.env.CAMPUS_SESSION_SECRET || process.env.DATABASE_URL;
  if (!source || source.length < 32) throw new Error("Set CAMPUS_SESSION_SECRET to a random value of at least 32 characters.");
  return createHash("sha256").update(`campus-problem-solver:${source}`).digest();
}

export async function hashPassword(password: string) {
  const salt = randomBytes(16);
  const derived = (await scrypt(password, salt, 64)) as Buffer;
  return `${salt.toString("hex")}:${derived.toString("hex")}`;
}

export async function verifyPassword(password: string, stored: string | null | undefined) {
  if (!stored) return false;
  const [saltText, hashText] = stored.split(":");
  if (!saltText || !hashText || !/^[a-f0-9]{32}$/.test(saltText) || !/^[a-f0-9]{128}$/.test(hashText)) return false;
  const derived = (await scrypt(password, Buffer.from(saltText, "hex"), 64)) as Buffer;
  return timingSafeEqual(derived, Buffer.from(hashText, "hex"));
}

export async function issueSession(openId: string) {
  return new SignJWT({ purpose: "campus-demo-session" })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(openId)
    .setIssuedAt()
    .setExpirationTime(`${SESSION_SECONDS}s`)
    .sign(sessionKey());
}

export async function resolveSession(token: string) {
  try {
    const { payload } = await jwtVerify(token, sessionKey(), { algorithms: ["HS256"] });
    if (payload.purpose !== "campus-demo-session" || typeof payload.sub !== "string") return null;
    return (await getUserByOpenId(payload.sub)) ?? null;
  } catch {
    return null;
  }
}

export function cookieOptions(): CookieOptions {
  const secure = process.env.CAMPUS_COOKIE_SECURE !== "false";
  return { httpOnly: true, secure, sameSite: secure ? "none" : "lax", path: "/", maxAge: SESSION_SECONDS * 1000 };
}

export function setSessionCookie(res: Response, token: string) {
  res.cookie(DEMO_COOKIE, token, cookieOptions());
}

export function clearSessionCookie(res: Response) {
  res.clearCookie(DEMO_COOKIE, { ...cookieOptions(), maxAge: -1 });
}

const attempts = new Map<string, { count: number; windowStart: number }>();
export function allowLoginAttempt(req: Request) {
  const ip = req.ip || "unknown";
  const now = Date.now();
  const entry = attempts.get(ip);
  if (!entry || now - entry.windowStart > 15 * 60_000) {
    attempts.set(ip, { count: 1, windowStart: now });
    return true;
  }
  if (entry.count >= 8) return false;
  entry.count += 1;
  if (attempts.size > 5_000) {
    for (const [key, value] of attempts) if (now - value.windowStart > 15 * 60_000) attempts.delete(key);
  }
  return true;
}
