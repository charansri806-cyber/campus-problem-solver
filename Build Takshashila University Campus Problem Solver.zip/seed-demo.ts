import "dotenv/config";
import { and, eq } from "drizzle-orm";
import { hashPassword } from "../server/auth/demo";
import { getDb, upsertUser } from "../server/db";
import { issues, issueStatusHistory, issueUpdates, users } from "../drizzle/schema";

async function main() {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_URL is required to seed demo data.");
  try {
    const studentEmail = "student.demo@campussolve.local";
    const adminEmail = "admin.demo@campussolve.local";
    const [studentHash, adminHash] = await Promise.all([hashPassword("StudentDemo!26"), hashPassword("AdminDemo!26")]);
    await upsertUser({ openId: "campussolve-demo-student", email: studentEmail, name: "Aarav Student (Demo)", loginMethod: "demo", role: "student", passwordHash: studentHash });
    await upsertUser({ openId: "campussolve-demo-admin", email: adminEmail, name: "Campus Admin (Demo)", loginMethod: "demo", role: "admin", passwordHash: adminHash });
    const [student] = await db.select().from(users).where(eq(users.openId, "campussolve-demo-student")).limit(1);
    const [admin] = await db.select().from(users).where(eq(users.openId, "campussolve-demo-admin")).limit(1);
    if (!student || !admin) throw new Error("Failed to initialize demo accounts.");

    const samples = [
      { reportId: "CPS-DEMO-0001", title: "Projector does not power on", category: "Classroom & laboratory equipment", location: "Sample location — North learning wing", description: "Fictional demonstration report: the projector in a sample teaching room does not appear to power on. No real room or campus is identified.", priority: "Medium" as const, status: "Under Review" as const, resolutionNote: null },
      { reportId: "CPS-DEMO-0002", title: "Wi-Fi signal drops in study space", category: "Wi-Fi & campus technology", location: "Sample location — Central library", description: "Fictional demonstration report: a network connection appears to drop intermittently in a sample study area. No real building is identified.", priority: "High" as const, status: "In Progress" as const, resolutionNote: null },
      { reportId: "CPS-DEMO-0003", title: "Water tap needs attention", category: "Water & washroom maintenance", location: "Sample location — Student commons", description: "Fictional demonstration report: a water tap in a sample common area appears to need maintenance. This record is synthetic demo data.", priority: "Low" as const, status: "Resolved" as const, resolutionNote: "Demo resolution: sample maintenance action recorded for prototype demonstration only." },
    ];

    for (const sample of samples) {
      await db.insert(issues).values({ ...sample, reporterId: student.id }).onDuplicateKeyUpdate({ set: { reportId: sample.reportId } });
      const [issue] = await db.select().from(issues).where(eq(issues.reportId, sample.reportId)).limit(1);
      if (!issue) continue;
      const submitted = await db.select({ id: issueStatusHistory.id }).from(issueStatusHistory).where(and(eq(issueStatusHistory.issueId, issue.id), eq(issueStatusHistory.newStatus, "Submitted"))).limit(1);
      if (!submitted.length) await db.insert(issueStatusHistory).values({ issueId: issue.id, previousStatus: null, newStatus: "Submitted", adminId: null, note: "Fictional demo report submitted." });
      const current = await db.select({ id: issueStatusHistory.id }).from(issueStatusHistory).where(and(eq(issueStatusHistory.issueId, issue.id), eq(issueStatusHistory.newStatus, sample.status))).limit(1);
      if (!current.length) await db.insert(issueStatusHistory).values({ issueId: issue.id, previousStatus: "Submitted", newStatus: sample.status, adminId: admin.id, note: "Fictional administrator update for demonstration." });
      if (sample.resolutionNote) {
        const [existingNote] = await db.select({ id: issueUpdates.id }).from(issueUpdates).where(and(eq(issueUpdates.issueId, issue.id), eq(issueUpdates.kind, "Resolution"))).limit(1);
        if (!existingNote) await db.insert(issueUpdates).values({ issueId: issue.id, authorId: admin.id, kind: "Resolution", note: sample.resolutionNote });
      }
    }
    console.log("Demo accounts and fictional demonstration reports are ready.");
  } finally {
    const client = (db as unknown as { $client?: { end?: () => Promise<void> } }).$client;
    if (client?.end) await client.end();
  }
}

main().catch(error => { console.error("Demo seed failed:", error); process.exitCode = 1; });
