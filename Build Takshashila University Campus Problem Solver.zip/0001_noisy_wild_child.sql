CREATE TABLE `issue_status_history` (
	`id` int AUTO_INCREMENT NOT NULL,
	`issueId` int NOT NULL,
	`previousStatus` varchar(40),
	`newStatus` varchar(40) NOT NULL,
	`adminId` int,
	`note` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `issue_status_history_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `issue_updates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`issueId` int NOT NULL,
	`authorId` int NOT NULL,
	`kind` enum('Progress','Resolution') NOT NULL,
	`note` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `issue_updates_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `issues` (
	`id` int AUTO_INCREMENT NOT NULL,
	`reportId` varchar(32) NOT NULL,
	`reporterId` int NOT NULL,
	`title` varchar(140) NOT NULL,
	`category` varchar(80) NOT NULL,
	`location` varchar(120) NOT NULL,
	`description` text NOT NULL,
	`priority` enum('Low','Medium','High') NOT NULL DEFAULT 'Medium',
	`status` enum('Submitted','Under Review','In Progress','Resolved','Rejected') NOT NULL DEFAULT 'Submitted',
	`resolutionNote` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `issues_id` PRIMARY KEY(`id`),
	CONSTRAINT `issues_reportId_unique` UNIQUE(`reportId`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','student','admin') NOT NULL DEFAULT 'user';--> statement-breakpoint
ALTER TABLE `users` ADD `passwordHash` varchar(255);--> statement-breakpoint
ALTER TABLE `issue_status_history` ADD CONSTRAINT `issue_status_history_issueId_issues_id_fk` FOREIGN KEY (`issueId`) REFERENCES `issues`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `issue_status_history` ADD CONSTRAINT `issue_status_history_adminId_users_id_fk` FOREIGN KEY (`adminId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `issue_updates` ADD CONSTRAINT `issue_updates_issueId_issues_id_fk` FOREIGN KEY (`issueId`) REFERENCES `issues`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `issue_updates` ADD CONSTRAINT `issue_updates_authorId_users_id_fk` FOREIGN KEY (`authorId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `issues` ADD CONSTRAINT `issues_reporterId_users_id_fk` FOREIGN KEY (`reporterId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `history_issue_idx` ON `issue_status_history` (`issueId`);--> statement-breakpoint
CREATE INDEX `history_created_idx` ON `issue_status_history` (`createdAt`);--> statement-breakpoint
CREATE INDEX `updates_issue_idx` ON `issue_updates` (`issueId`);--> statement-breakpoint
CREATE INDEX `updates_author_idx` ON `issue_updates` (`authorId`);--> statement-breakpoint
CREATE INDEX `issues_reporter_idx` ON `issues` (`reporterId`);--> statement-breakpoint
CREATE INDEX `issues_status_idx` ON `issues` (`status`);--> statement-breakpoint
CREATE INDEX `issues_category_location_idx` ON `issues` (`category`,`location`);--> statement-breakpoint
CREATE INDEX `issues_created_idx` ON `issues` (`createdAt`);