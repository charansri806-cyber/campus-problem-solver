import { randomUUID } from "node:crypto";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getAdminAnalytics, getIssue, getStudentStats, getUserByEmail, createIssue, findPotentialDuplicates, listAdminIssues, listStudentIssues, updateIssue } from "./db";
import { allowLoginAttempt, clearSessionCookie, issueSession, setSessionCookie, verifyPassword } from "./auth/demo";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";

const statuses = ["Submitted", "Under Review", "In Progress", "Resolved", "Rejected"] as const;
const priorities = ["Low", "Medium", "High"] as const;
const studentProcedure = protectedProcedure.use(async ({ ctx, next }) => {
  if (ctx.user.role !== "student") throw new TRPCError({ code: "FORBIDDEN", message: "Student access only." });
  return next({ ctx: { ...ctx, user: ctx.user } });
});
const issueFilters = z.object({ search: z.string().max(100).optional(), status: z.enum(statuses).optional(), category: z.string().max(80).optional() });
const categories = ["Classroom & laboratory equipment", "Cleanliness & waste", "Water & washroom maintenance", "Wi-Fi & campus technology", "Building & infrastructure", "Library & study spaces", "Accessibility & non-emergency safety", "Other campus facilities"] as const;
const categorySchema = z.enum(categories);

export const appRouter = router({
  auth: router({
    me: publicProcedure.query(({ ctx }) => ctx.user ? { id: ctx.user.id, name: ctx.user.name, email: ctx.user.email, role: ctx.user.role } : null),
    login: publicProcedure.input(z.object({ email: z.string().email().max(320), password: z.string().min(1).max(128) })).mutation(async ({ input, ctx }) => {
      if (!allowLoginAttempt(ctx.req)) throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Too many sign-in attempts. Please wait and try again." });
      const user = await getUserByEmail(input.email.trim().toLowerCase());
      const valid = user && (user.role === "student" || user.role === "admin") && await verifyPassword(input.password, user.passwordHash);
      if (!valid) throw new TRPCError({ code: "UNAUTHORIZED", message: "Email or password is incorrect." });
      const token = await issueSession(user.openId);
      setSessionCookie(ctx.res, token);
      return { id: user.id, name: user.name, email: user.email, role: user.role };
    }),
    logout: publicProcedure.mutation(({ ctx }) => { clearSessionCookie(ctx.res); return { success: true }; }),
  }),
  student: router({
    stats: studentProcedure.query(({ ctx }) => getStudentStats(ctx.user.id)),
    list: studentProcedure.input(issueFilters).query(({ ctx, input }) => listStudentIssues(ctx.user.id, input)),
    detail: studentProcedure.input(z.object({ reportId: z.string().min(5).max(32) })).query(async ({ ctx, input }) => {
      const result = await getIssue(input.reportId, ctx.user.id, false);
      if (!result) throw new TRPCError({ code: "NOT_FOUND", message: "Report not found." });
      return result;
    }),
    potentialDuplicates: studentProcedure.input(z.object({ title: z.string().min(3).max(140), category: categorySchema, location: z.string().min(2).max(120) })).query(({ input }) => findPotentialDuplicates(input)),
    submit: studentProcedure.input(z.object({ title: z.string().trim().min(5).max(140), category: categorySchema, location: z.string().trim().min(2).max(120), description: z.string().trim().min(15).max(5000), priority: z.enum(priorities), confirmPotentialDuplicate: z.boolean().default(false) })).mutation(async ({ ctx, input }) => {
      const matches = await findPotentialDuplicates(input);
      if (matches.length && !input.confirmPotentialDuplicate) return { created: null, potentialDuplicates: matches };
      const reportId = `CPS-${new Date().toISOString().slice(0, 10).replaceAll("-", "")}-${randomUUID().slice(0, 6).toUpperCase()}`;
      const created = await createIssue({ reporterId: ctx.user.id, title: input.title, category: input.category, location: input.location, description: input.description, priority: input.priority, reportId });
      return { created, potentialDuplicates: matches };
    }),
  }),
  admin: router({
    analytics: adminProcedure().query(() => getAdminAnalytics()),
    list: adminProcedure().input(z.object({ search: z.string().max(100).optional(), status: z.enum(statuses).optional(), priority: z.enum(priorities).optional(), category: z.string().max(80).optional(), location: z.string().max(120).optional(), dateFrom: z.string().regex(/^\\d{4}-\\d{2}-\\d{2}$/).optional(), dateTo: z.string().regex(/^\\d{4}-\\d{2}-\\d{2}$/).optional() })).query(({ input }) => listAdminIssues(input)),
    detail: adminProcedure().input(z.object({ reportId: z.string().min(5).max(32) })).query(async ({ ctx, input }) => {
      const result = await getIssue(input.reportId, ctx.user.id, true);
      if (!result) throw new TRPCError({ code: "NOT_FOUND", message: "Report not found." });
      return result;
    }),
    update: adminProcedure().input(z.object({ reportId: z.string().min(5).max(32), status: z.enum(statuses), priority: z.enum(priorities), note: z.string().trim().max(2000).optional(), noteKind: z.enum(["Progress", "Resolution"]).optional() })).mutation(async ({ ctx, input }) => {
      const result = await updateIssue({ ...input, adminId: ctx.user.id });
      if (!result) throw new TRPCError({ code: "NOT_FOUND", message: "Report not found." });
      return result;
    }),
  }),
});

function adminProcedure() {
  return protectedProcedure.use(async ({ ctx, next }) => {
    if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Administrator access required." });
    return next({ ctx: { ...ctx, user: ctx.user } });
  });
}

export type AppRouter = typeof appRouter;
