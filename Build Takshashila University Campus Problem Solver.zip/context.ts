import { parse as parseCookie } from "cookie";
import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import { DEMO_COOKIE, resolveSession } from "../auth/demo";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
};

export async function createContext(opts: CreateExpressContextOptions): Promise<TrpcContext> {
  let user: User | null = null;
  try {
    const token = parseCookie(opts.req.headers.cookie || "")[DEMO_COOKIE];
    if (typeof token === "string") user = await resolveSession(token);
  } catch {
    user = null;
  }
  return { req: opts.req, res: opts.res, user };
}
