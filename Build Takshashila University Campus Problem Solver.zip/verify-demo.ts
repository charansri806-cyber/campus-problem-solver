import "dotenv/config";
import { appRouter } from "../server/routers";
import { getDb, getIssue, getUserByEmail } from "../server/db";
import { DEMO_COOKIE, resolveSession } from "../server/auth/demo";
import type { TrpcContext } from "../server/_core/context";

function assert(condition: unknown, message: string): asserts condition {
  if (!condition) throw new Error(`Verification failed: ${message}`);
}
function context(user: TrpcContext["user"], cookie = ""): TrpcContext {
  return {
    user,
    req: { ip: "127.0.0.1", headers: { cookie }, protocol: "https" } as TrpcContext["req"],
    res: { cookie: () => undefined, clearCookie: () => undefined } as unknown as TrpcContext["res"],
  };
}

async function main() {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_URL is required.");
  try {
    const captured: Record<string, string> = {};
    const loginContext = context(null);
    loginContext.res.cookie = ((name: string, value: string) => { captured[name] = value; }) as typeof loginContext.res.cookie;
    const signedIn = await appRouter.createCaller(loginContext).auth.login({ email: "student.demo@campussolve.local", password: "StudentDemo!26" });
    assert(signedIn.role === "student", "student demo login returns the student role");
    assert(Boolean(captured[DEMO_COOKIE]), "login issues the app-specific session cookie");
    const sessionUser = await resolveSession(captured[DEMO_COOKIE]!);
    assert(sessionUser?.id === signedIn.id, "the signed session resolves against the persistent user record");

    const student = await getUserByEmail("student.demo@campussolve.local");
    const admin = await getUserByEmail("admin.demo@campussolve.local");
    assert(student && admin, "both demo accounts exist in MySQL");
    const studentApi = appRouter.createCaller(context(student));
    const adminApi = appRouter.createCaller(context(admin));
    const ownReports = await studentApi.student.list({});
    assert(ownReports.length >= 3, "student can list seeded reports");
    const detail = await studentApi.student.detail({ reportId: "CPS-DEMO-0001" });
    assert(detail.history.some(event => event.newStatus === "Under Review"), "student can read their update history");
    assert(await getIssue("CPS-DEMO-0001", admin.id, false) === null, "an account that does not own a report cannot retrieve it through the ownership-scoped query");
    const analytics = await adminApi.admin.analytics();
    assert(analytics.total >= 3 && analytics.categories.length > 0, "admin analytics are derived from persistent records");
    assert((await adminApi.admin.list({ search: "projector" })).some(report => report.reportId === "CPS-DEMO-0001"), "admin search returns the matching report");
    const adminDetail = await adminApi.admin.detail({ reportId: "CPS-DEMO-0001" });
    assert(adminDetail.history.length > 0, "admin can inspect report history");
    const duplicates = await studentApi.student.potentialDuplicates({ title: "Projector does not power on", category: "Classroom & laboratory equipment", location: "Sample location — North learning wing" });
    assert(duplicates.some(item => item.reportId === "CPS-DEMO-0001"), "same-category/location title similarity triggers a duplicate warning");

    let forbidden = false;
    try { await studentApi.admin.analytics(); } catch (error) { forbidden = (error as { code?: string }).code === "FORBIDDEN"; }
    assert(forbidden, "student role cannot call admin procedures");
    let unauthenticated = false;
    try { await appRouter.createCaller(context(null)).student.stats(); } catch (error) { unauthenticated = (error as { code?: string }).code === "UNAUTHORIZED"; }
    assert(unauthenticated, "unauthenticated requests cannot call protected student procedures");
    let invalidRejected = false;
    try { await studentApi.student.submit({ title: "x", category: "Classroom & laboratory equipment", location: "Sample", description: "too short", priority: "Medium", confirmPotentialDuplicate: false }); } catch (error) { invalidRejected = (error as { code?: string }).code === "BAD_REQUEST"; }
    assert(invalidRejected, "server validation rejects invalid report submissions");

    console.log("PASS: demo login, signed session, student list/detail, ownership isolation, admin analytics/search/detail, duplicate warning, student role denial, unauthenticated denial, invalid submission rejection.");
    console.log("Not exercised by this read-only verifier: creating a new report, changing status/priority, and restart persistence.");
  } finally {
    const client = (db as unknown as { $client?: { end?: () => Promise<void> } }).$client;
    if (client?.end) await client.end();
  }
}

main().catch(error => { console.error(error); process.exitCode = 1; });
