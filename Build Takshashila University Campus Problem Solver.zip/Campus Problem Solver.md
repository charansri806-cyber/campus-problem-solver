# Campus Problem Solver

A student-developed campus issue reporting prototype for potential demonstration to the Institution's Innovation Council at Takshashila University, Chennai. It is **not officially approved, operated, or integrated with Takshashila University** and it is **not an emergency reporting service**. Reports are stored in this prototype database only; they are not sent to University staff. For urgent matters, contact appropriate University personnel or emergency services directly.

The user supplied the Takshashila University logo after the initial prototype was built. The original PNG is retained byte-for-byte at `branding/takshashila-university-logo.png` and displayed without alteration from project storage. Its display does not imply University approval, operation, or integration; the product remains an independent student prototype. All seeded locations and reports are fictional demonstrations.

## Architecture

- React + TypeScript responsive web client.
- Express + tRPC API, with server-side Zod validation and role/ownership authorization.
- Drizzle ORM and managed MySQL database; `drizzle/schema.ts` declares users, issues, status history, and administrator updates.
- Passwords use Node.js scrypt hashes. A 12-hour signed HS256 cookie identifies a demo account; every request validates the signature and loads the account/role from the database. Student reads are scoped by the authenticated account. Admin procedures verify the administrator role server-side.
- The approved hosted setup uses managed MySQL rather than the prompt's preferred local SQLite option. Managed database data survives app/server restarts, but development and published instances share the same database. Do not run a destructive reset against shared or real data.

## Requirements

Node.js 20+ and pnpm 10.18.0. For managed WebDev Preview use the provisioned database connection. For a separate local environment provide a MySQL-compatible `DATABASE_URL` and strong session secret in `.env`.

## Setup and run

```sh
pnpm install
cp .env.example .env
# Edit .env: configure DATABASE_URL and CAMPUS_SESSION_SECRET.
# For plain HTTP localhost only, set CAMPUS_COOKIE_SECURE=false.
pnpm db:push
pnpm db:seed:demo
pnpm dev
```

Open `http://localhost:3000` for local development. In WebDev Preview, the default cookie mode is Secure + SameSite=None for cross-site HTTPS embedding. `CAMPUS_COOKIE_SECURE=false` is only for plain HTTP local testing; do not use it on an HTTPS/public deployment. Configure `CAMPUS_SESSION_SECRET` to a random secret of at least 32 characters for a dedicated app-owned key. If unset, this prototype derives its key from the server-only `DATABASE_URL`; rotating the database credentials invalidates existing sessions. Never put secrets in client code or commit `.env`.

## Fictional demo credentials

| Role | Email | Password |
| --- | --- | --- |
| Student | `student.demo@campussolve.local` | `StudentDemo!26` |
| Administrator | `admin.demo@campussolve.local` | `AdminDemo!26` |

These credentials and records are synthetic demo data. Do not reuse real student or university credentials. The sign-in page directs demonstrators to this README rather than embedding admin credentials in public frontend code.

## Database and reset

`pnpm db:push` generates and applies additive Drizzle migrations. The migration adds application tables and a nullable password-hash field to the starter users table while preserving existing rows. Review generated SQL before applying schema changes elsewhere.

`pnpm db:seed:demo` is idempotent for fixed demo account/report IDs. It re-hashes/resets the two demo passwords on each run and inserts missing synthetic history/updates; it does not delete other records. To remove only demo fixtures from a disposable **local test database**, manually delete their issue history/updates/reports and the two `campussolve-demo-*` user rows in foreign-key-safe order, then seed again. There is intentionally no automatic whole-database reset command. Managed development and published environments share state; do not delete their data as a reset.

## Useful commands

```sh
pnpm check          # TypeScript check
pnpm test           # Unit tests
pnpm build          # Build frontend and backend
pnpm db:push        # Generate and apply schema migration
pnpm db:seed:demo   # Insert fictional demo accounts and reports
pnpm verify:demo    # Read-only tRPC and managed database workflow checks
```

## Implemented behavior

- Student/admin demo sign-in with hashed passwords, server-issued HTTP-only sessions, role-protected endpoints, bounded JSON bodies, and an in-memory sign-in-attempt limiter.
- Student dashboard quick lookup plus own-report list/detail/history; validated category/location/priority submission; unique report IDs; data-derived metrics; search/status filters; and review-before-submit similar-open-report warning.
- Admin dashboard with database-derived issue counts/category/location summaries, review of transparent potential-duplicate pairs, report filters and management, admin-only status/priority changes, progress/resolution notes, and persistent history records.
- Responsive navigation, accessible status/priority indicators, loading/error/empty states, prototype and emergency notices, and fictional sample records. The visual system follows the supplied logo with warm-white surfaces, graphite structure, and restrained orange accents sampled from the mark (#F05D2D).

## Tests and completion status

Run `pnpm check`, `pnpm test`, and `pnpm build`. The unit tests cover password hashing, session-cookie defaults, logout, and starter platform behavior. `pnpm verify:demo` is a read-only check of login, session resolution, student listing/detail, ownership-scoped retrieval, admin analytics/search/detail, duplicate warning, role denial, unauthenticated denial, and validation. It does not create a report, change a status, or verify restart persistence; those require a separate explicit demo workflow and are not claimed as covered by this read-only command.

## Incomplete/external requirements and limitations

- The supplied logo is included and displayed unchanged. University authentication, staff routing, email, uploads, QR codes, and production integrations are not implemented.
- Duplicate matching is token-overlap similarity but currently compares recent open issues with the same category and exact sample location. It is a transparent heuristic, not AI.
- The login-attempt limiter is process-local and resets when the server restarts. Add shared rate limiting and operational monitoring before public deployment.
- Demo passwords are for demonstrations only. Rotate/remove demo accounts before a real pilot; use a reviewed credential lifecycle, CSRF strategy, shared rate limiting, logging/retention rules, and University-approved procedures.
- No public deployment is authorized. Before a campus pilot, obtain University permission, identify authorized report reviewers, agree response procedures, and complete security/privacy review. Do not enter sensitive, emergency, or real student information.

## IIC architecture explanation

The interface is a React client; calls go to a typed Express/tRPC API. The API validates inputs and determines the signed-in demo user's role from a server-verified cookie and persistent user record. Student report queries include the authenticated user ID in their database predicate, while administrator procedures have a separate role gate. Drizzle maps issue records, status history, and administrator notes to managed MySQL. Transactions keep a report or admin status change and its history entry together. Dashboards calculate metrics from stored reports rather than fabricated totals. Campus locations remain fictional and the prototype does not claim to contact University staff.
