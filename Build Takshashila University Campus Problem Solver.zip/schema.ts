import { index, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "student", "admin"]).default("user").notNull(),
  passwordHash: varchar("passwordHash", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const issues = mysqlTable("issues", {
  id: int("id").autoincrement().primaryKey(),
  reportId: varchar("reportId", { length: 32 }).notNull().unique(),
  reporterId: int("reporterId").notNull().references(() => users.id),
  title: varchar("title", { length: 140 }).notNull(),
  category: varchar("category", { length: 80 }).notNull(),
  location: varchar("location", { length: 120 }).notNull(),
  description: text("description").notNull(),
  priority: mysqlEnum("priority", ["Low", "Medium", "High"]).default("Medium").notNull(),
  status: mysqlEnum("status", ["Submitted", "Under Review", "In Progress", "Resolved", "Rejected"]).default("Submitted").notNull(),
  resolutionNote: text("resolutionNote"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, table => [index("issues_reporter_idx").on(table.reporterId), index("issues_status_idx").on(table.status), index("issues_category_location_idx").on(table.category, table.location), index("issues_created_idx").on(table.createdAt)]);

export const issueStatusHistory = mysqlTable("issue_status_history", {
  id: int("id").autoincrement().primaryKey(),
  issueId: int("issueId").notNull().references(() => issues.id),
  previousStatus: varchar("previousStatus", { length: 40 }),
  newStatus: varchar("newStatus", { length: 40 }).notNull(),
  adminId: int("adminId").references(() => users.id),
  note: text("note"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [index("history_issue_idx").on(table.issueId), index("history_created_idx").on(table.createdAt)]);

export const issueUpdates = mysqlTable("issue_updates", {
  id: int("id").autoincrement().primaryKey(),
  issueId: int("issueId").notNull().references(() => issues.id),
  authorId: int("authorId").notNull().references(() => users.id),
  kind: mysqlEnum("kind", ["Progress", "Resolution"]).notNull(),
  note: text("note").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, table => [index("updates_issue_idx").on(table.issueId), index("updates_author_idx").on(table.authorId)]);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Issue = typeof issues.$inferSelect;
export type IssueStatusHistory = typeof issueStatusHistory.$inferSelect;
export type IssueUpdate = typeof issueUpdates.$inferSelect;
