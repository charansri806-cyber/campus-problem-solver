import { afterEach, describe, expect, it, vi } from "vitest";
import { cookieOptions, hashPassword, verifyPassword } from "./demo";

afterEach(() => vi.unstubAllEnvs());

describe("demo authentication helpers", () => {
  it("stores a salted scrypt digest and verifies only the matching password", async () => {
    const first = await hashPassword("FictionalPassword-123");
    const second = await hashPassword("FictionalPassword-123");
    expect(first).not.toBe(second);
    expect(first).not.toContain("FictionalPassword-123");
    expect(await verifyPassword("FictionalPassword-123", first)).toBe(true);
    expect(await verifyPassword("wrong-password", first)).toBe(false);
    expect(await verifyPassword("FictionalPassword-123", null)).toBe(false);
  });

  it("defaults to a Secure, HttpOnly cross-site cookie for hosted Preview", () => {
    vi.stubEnv("CAMPUS_COOKIE_SECURE", "true");
    const cookie = cookieOptions();
    expect(cookie.httpOnly).toBe(true);
    expect(cookie.secure).toBe(true);
    expect(cookie.sameSite).toBe("none");
    expect(cookie.path).toBe("/");
  });

  it("supports an explicit plain-HTTP localhost cookie setting", () => {
    vi.stubEnv("CAMPUS_COOKIE_SECURE", "false");
    const cookie = cookieOptions();
    expect(cookie.secure).toBe(false);
    expect(cookie.sameSite).toBe("lax");
  });
});
